Plugin to support twisted trial.

From: http://twistedmatrix.com/documents/13.1.0/core/howto/plugin.html
 if a directory which has been added to sys.path (typically by adding it to the PYTHONPATH environment variable) contains a directory
 named twisted/plugins/, each .py file in that directory will be loaded as a source of plugins.
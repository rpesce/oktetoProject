def method1():
    return 1


def method2():
    return 2


if __name__ == '__main__':
    method1()  # break here
    method2()
    print('TEST SUCEEDED!')

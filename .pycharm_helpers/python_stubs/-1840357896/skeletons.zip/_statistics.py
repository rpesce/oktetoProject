# encoding: utf-8
# module _statistics
# from /usr/local/lib/python3.8/lib-dynload/_statistics.cpython-38-x86_64-linux-gnu.so
# by generator 1.147
""" Accelerators for the statistics module. """
# no imports

# functions

def _normal_dist_inv_cdf(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_statistics', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>, origin='/usr/local/lib/python3.8/lib-dynload/_statistics.cpython-38-x86_64-linux-gnu.so')"


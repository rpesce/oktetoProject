# encoding: utf-8
# module _uuid
# from /usr/local/lib/python3.8/lib-dynload/_uuid.cpython-38-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# Variables with simple values

has_uuid_generate_time_safe = 1

# functions

def generate_time_safe(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_uuid', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>, origin='/usr/local/lib/python3.8/lib-dynload/_uuid.cpython-38-x86_64-linux-gnu.so')"


# encoding: utf-8
# module _crypt
# from /usr/local/lib/python3.8/lib-dynload/_crypt.cpython-38-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def crypt(*args, **kwargs): # real signature unknown
    """
    Hash a *word* with the given *salt* and return the hashed password.
    
    *word* will usually be a user's password.  *salt* (either a random 2 or 16
    character string, possibly prefixed with $digit$ to indicate the method)
    will be used to perturb the encryption algorithm and produce distinct
    results for a given *word*.
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_crypt', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>, origin='/usr/local/lib/python3.8/lib-dynload/_crypt.cpython-38-x86_64-linux-gnu.so')"


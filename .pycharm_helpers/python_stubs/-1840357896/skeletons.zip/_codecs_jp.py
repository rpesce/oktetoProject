# encoding: utf-8
# module _codecs_jp
# from /usr/local/lib/python3.8/lib-dynload/_codecs_jp.cpython-38-x86_64-linux-gnu.so
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>'

__map_cp932ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01e10>'

__map_jisx0208 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d012d0>'

__map_jisx0212 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01360>'

__map_jisx0213_1_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01930>'

__map_jisx0213_1_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01270>'

__map_jisx0213_2_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01120>'

__map_jisx0213_2_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d014e0>'

__map_jisx0213_bmp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d011b0>'

__map_jisx0213_emp = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01ab0>'

__map_jisx0213_pair = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d01de0>'

__map_jisxcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x7f7004d012a0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_codecs_jp', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>, origin='/usr/local/lib/python3.8/lib-dynload/_codecs_jp.cpython-38-x86_64-linux-gnu.so')"


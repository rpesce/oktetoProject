# encoding: utf-8
# module _testimportmultiple
# from /usr/local/lib/python3.8/lib-dynload/_testimportmultiple.cpython-38-x86_64-linux-gnu.so
# by generator 1.147
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testimportmultiple', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x7f7004d01af0>, origin='/usr/local/lib/python3.8/lib-dynload/_testimportmultiple.cpython-38-x86_64-linux-gnu.so')"

